﻿using OpenAI.Images;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Retrobator.AI.OpenAI;

sealed class ImageGenerator : IImageGenerator
{
    public static readonly string[] ImageQualities = ["standard", "hd"];
    public static readonly string[] ImageStyles = ["vivid", "natural"];
    readonly ImageClient _client;

    public ImageGenerator(string apiKey, string model)
    {
        Model = model;
        _client = new(model, apiKey);
    }

    public string Model { get; }
    public string ImageQuality { get; set; } = "standard";
    public string ImageStyle { get; set; } = "vivid";

    public async Task<Image> GenerateImageAsync(string prompt, ImageSize size, CancellationToken cancellationToken = default)
    {
        ImageGenerationOptions options = new()
        {
            Quality = ImageQuality,
            Size = size == ImageSize.Normal ? GeneratedImageSize.W1024xH1024 : GeneratedImageSize.W1792xH1024,
            Style = ImageStyle,
            ResponseFormat = GeneratedImageFormat.Bytes
        };

        GeneratedImage image = await _client.GenerateImageAsync(prompt, options, cancellationToken);
        BinaryData bytes = image.ImageBytes;

        return Image.FromStream(bytes.ToStream());
    }
}
