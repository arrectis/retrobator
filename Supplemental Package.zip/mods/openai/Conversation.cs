﻿using Microsoft.Extensions.Logging;
using OpenAI.RealtimeConversation;
using System;
using System.ClientModel;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace Retrobator.AI.OpenAI;

#pragma warning disable OPENAI002 // Type is for evaluation purposes only and is subject to change or removal in future updates. Suppress this diagnostic to proceed.

sealed class Conversation : IConversation, IAsyncDisposable
{
    public static readonly string[] Voices = ["sage", "echo", "shimmer", "ash", "ballad", "coral", "alloy"];
    static readonly TimeSpan MaxSessionTime = TimeSpan.FromMinutes(14); // Sessions are currently limited to 15 minutes; recycle before then.
    readonly RealtimeConversationClient _client;
    readonly ILogger _logger;
    readonly SemaphoreSlim _interruptLock = new(1);
    readonly SemaphoreSlim _responseLock = new(1);
    readonly ConcurrentDictionary<string, FunctionBase> _functionsByName = new();
    RealtimeConversationSession _session;
    TimeSpan _sessionBeginTime;
    CancellationTokenSource _sessionCancellationTokenSource;
    ConversationResponse _currentResponse;
    IFunctionExecutor _currentFunctionExecutor;

    public Conversation(string apiKey, string model, ILogger logger)
    {
        Model = model;
        _logger = logger;

        _client = new RealtimeConversationClient(Model, new ApiKeyCredential(apiKey));
    }

    public async ValueTask DisposeAsync()
    {
        _sessionCancellationTokenSource?.Cancel();
        await _interruptLock.WaitAsync();
        await _responseLock.WaitAsync();
        _session?.Dispose();
    }

    public string Model { get; }
    public float Temperature { get; set; } = 0.8f;

    public ICollection<string> GetValidVoices() => Voices;

    public async Task<ConversationResponse> AddTextAsync(
        string text,
        string instructions,
        ICollection<FunctionBase> functions,
        IFunctionExecutor functionExecutor,
        bool allowAudioResponse = false,
        string responseVoice = null,
        Action<ConversationResponse> responseCallback = null,
        CancellationToken cancellationToken = default)
    {
        _currentFunctionExecutor = functionExecutor;
        _currentResponse = new ConversationResponse();
        responseCallback?.Invoke(_currentResponse);

        await _interruptLock.WaitAsync();

        try
        {
            if (_responseLock.CurrentCount == 0)
            {
                _logger.LogDebug("Conversation interrupt.");
                await _session.InterruptResponseAsync();
            }

            await RefreshSession();

            await ConfigureSessionAsync(_session, instructions, allowAudioResponse, responseVoice, functions, cancellationToken);

            await _session.AddItemAsync(ConversationItem.CreateUserMessage([text]), cancellationToken: cancellationToken);

            await _responseLock.WaitAsync();

            try
            {
                await _session.StartResponseAsync(_sessionCancellationTokenSource.Token);
            }
            catch (Exception)
            {
                _responseLock.Release();
                throw;
            }
        }
        finally
        {
            _interruptLock.Release();
        }

        return _currentResponse;
    }

    public async Task<ConversationResponse> AddAudioAsync(
        Stream audio,
        string instructions,
        ICollection<FunctionBase> functions,
        IFunctionExecutor functionExecutor,
        bool allowAudioResponse = false,
        string responseVoice = null,
        Action<ConversationResponse> responseCallback = null,
        CancellationToken cancellationToken = default) //
    {
        _currentFunctionExecutor = functionExecutor;
        _currentResponse = new ConversationResponse();
        responseCallback?.Invoke(_currentResponse);

        await _interruptLock.WaitAsync();

        try
        {
            if (_responseLock.CurrentCount == 0)
            {
                _logger.LogDebug("Conversation interrupt.");
                await _session.InterruptResponseAsync();
            }

            await RefreshSession();

            await ConfigureSessionAsync(_session, instructions, allowAudioResponse, responseVoice, functions, cancellationToken);

            await _session.SendInputAudioAsync(audio, cancellationToken);

            await _session.CommitPendingAudioAsync(cancellationToken);

            await _responseLock.WaitAsync();

            try
            {
                await _session.StartResponseAsync(_sessionCancellationTokenSource.Token);
            }
            catch (Exception)
            {
                _responseLock.Release();
                throw;
            }
        }
        finally
        {
            _interruptLock.Release();
        }

        return _currentResponse;
    }

    async Task RefreshSession()
    {
        var time = TimeSpan.FromTicks(DateTime.UtcNow.Ticks);
        bool sessionExpired = _session != null && time - _sessionBeginTime > MaxSessionTime;

        if (_session == null || sessionExpired)
        {
            _sessionCancellationTokenSource?.Cancel();

            // Wait for the session thread to finish, if any.
            await _responseLock.WaitAsync();

            try
            {
                _sessionCancellationTokenSource = new CancellationTokenSource();
                _session = await _client.StartConversationSessionAsync(_sessionCancellationTokenSource.Token);
                if (_session == null)
                    throw new Exception("Failed to start conversation session.");

                HandleSession(_session, _sessionCancellationTokenSource.Token);
                _sessionBeginTime = time;
                _logger.LogDebug("Started new conversation session.");
            }
            finally
            {
                _responseLock.Release();
            }
        }
    }

    async Task ConfigureSessionAsync(
        RealtimeConversationSession session,
        string instructions,
        bool allowAudioResponse,
        string responseVoice,
        IEnumerable<FunctionBase> functions,
        CancellationToken cancellationToken)
    {
        if (responseVoice == null || !Voices.Contains(responseVoice))
            responseVoice = Voices[0];

        ConversationSessionOptions options = new()
        {
            //https://platform.openai.com/docs/guides/realtime/integration
            Instructions = instructions,
            Voice = responseVoice,
            InputAudioFormat = ConversationAudioFormat.Pcm16,
            OutputAudioFormat = ConversationAudioFormat.Pcm16,
            Temperature = Temperature,
            ContentModalities = ConversationContentModalities.Text,
            TurnDetectionOptions = ConversationTurnDetectionOptions.CreateDisabledTurnDetectionOptions(),

            // Transcribe the input audio so that we can record the text conversation.
            InputTranscriptionOptions = new ConversationInputTranscriptionOptions()
            {
                Model = "whisper-1",
            },
        };

        if (allowAudioResponse)
            options.ContentModalities |= ConversationContentModalities.Audio;

        _functionsByName.Clear();
        if (functions != null)
        {
            //options.ToolChoice = ConversationToolChoice.CreateAutoToolChoice(); // TODO: put back in (API bug)
            foreach (var function in functions)
            {
                _functionsByName[function.Name] = function;
                options.Tools.Add(BuildTool(function));
            }
        }

        await session.ConfigureSessionAsync(options, cancellationToken);
    }

    async void HandleSession(
        RealtimeConversationSession session,
        CancellationToken cancellationToken)
    {
        List<Task<ConversationItem>> toolCallTasks = [];

        try
        {
            await foreach (ConversationUpdate update in session.ReceiveUpdatesAsync(cancellationToken))
            {
                switch (update)
                {
                    case ConversationSessionStartedUpdate sessionStartedUpdate:
                        _logger.LogDebug("Conversation session started.");
                        break;
                    case ConversationSessionConfiguredUpdate conversationSessionConfiguredUpdate:
                        _logger.LogDebug("Conversation session configured.");
                        break;
                    case ConversationInputTranscriptionFailedUpdate inputTranscriptionFailedUpdate:
                        _logger.LogError(inputTranscriptionFailedUpdate.ErrorMessage);
                        break;
                    case ConversationItemStreamingPartDeltaUpdate conversationItemStreamingPartDeltaUpdate:

                        // With audio output enabled, the audio transcript of the delta update contains an approximation of
                        // the words spoken by the model. Without audio output, the text of the delta update will contain
                        // the segments making up the text content of a message.
                        var text = string.IsNullOrEmpty(conversationItemStreamingPartDeltaUpdate.AudioTranscript)
                            ? conversationItemStreamingPartDeltaUpdate.Text
                            : conversationItemStreamingPartDeltaUpdate.AudioTranscript;
                        if (!string.IsNullOrEmpty(text))
                        {
                            _currentResponse.AppendText(text);
                        }

                        if (conversationItemStreamingPartDeltaUpdate.AudioBytes != null)
                        {
                            var bytes = conversationItemStreamingPartDeltaUpdate.AudioBytes.ToArray();
                            var arr = new short[bytes.Length / 2];
                            Buffer.BlockCopy(bytes, 0, arr, 0, bytes.Length);
                            ApplyGain(arr, 6);
                            _currentResponse.AppendAudio(arr);
                        }

                        break;
                    case ConversationItemStreamingFinishedUpdate conversationItemStreamingFinishedUpdate:
                        // Item finished updates arrive when all streamed data for an item has arrived and the
                        // accumulated results are available. In the case of function calls, this is the point
                        // where all arguments are expected to be present.
                        if (conversationItemStreamingFinishedUpdate.FunctionName != null)
                        {
                            if (_functionsByName.TryGetValue(conversationItemStreamingFinishedUpdate.FunctionName, out var function) == false)
                            {
                                var errorTask = Task.FromResult(ConversationItem.CreateFunctionCallOutput(conversationItemStreamingFinishedUpdate.FunctionCallId, $"Error: Specified function not available."));
                                toolCallTasks.Add(errorTask);
                                break;
                            }

                            bool errored = false;
                            Dictionary<string, object> args = new();
                            if (conversationItemStreamingFinishedUpdate.FunctionCallArguments != null)
                            {
                                try
                                {
                                    using JsonDocument argumentsJson = JsonDocument.Parse(conversationItemStreamingFinishedUpdate.FunctionCallArguments);

                                    foreach (var prop in argumentsJson.RootElement.EnumerateObject())
                                    {
                                        args[prop.Name] = prop.Value.Clone();
                                    }
                                }
                                catch (JsonException ex)
                                {
                                    errored = true;
                                    _logger.LogError(ex, "OpenAI API returned invalid JSON function call arguments.");
                                }
                            }

                            if (!errored)
                            {
                                // Execute the tool and continue.
                                var task = ExecuteTool(conversationItemStreamingFinishedUpdate.FunctionCallId, function, args, _currentFunctionExecutor);
                                toolCallTasks.Add(task);
                            }
                        }

                        break;
                    case ConversationResponseFinishedUpdate conversationResponseFinishedUpdate:
                        _logger.LogDebug("Model response finished.");

                        // TODO: May not be needed once API is fixed, or check the Details property.
                        if (conversationResponseFinishedUpdate.Status != ConversationStatus.Completed)
                        {
                            _logger.LogError($"OpenAI API returned '{conversationResponseFinishedUpdate.Status}'. Details: {conversationResponseFinishedUpdate.StatusDetails}");

                            if (_responseLock.CurrentCount == 0)
                                _responseLock.Release();

                            break;
                        }

                        // If there are no tools requested by the model, we are done.
                        if (toolCallTasks.Count == 0)
                        {
                            _currentResponse.Complete();
                            _currentResponse = null;

                            if (_responseLock.CurrentCount == 0)
                                _responseLock.Release();

                            break;
                        }

                        // Wait for the tool calls to complete, respond to the model with the results, and wait for the next response.
                        var items = await Task.WhenAll(toolCallTasks);
                        foreach (var item in items)
                        {
                            await session.AddItemAsync(item, cancellationToken: cancellationToken);
                        }
                        toolCallTasks.Clear();

                        // Wait for the next response.
                        await session.StartResponseAsync(cancellationToken);
                        break;
                    case ConversationErrorUpdate conversationErrorUpdate:
                        if (_responseLock.CurrentCount == 0)
                            _responseLock.Release();

                        _logger.LogError(conversationErrorUpdate.Message);
                        break;
                    default:
                        break;
                }
            }
        }
        finally
        {
            if (_responseLock.CurrentCount == 0)
                _responseLock.Release();

            _session?.Dispose();
            _session = null;
        }
    }

    static async Task<ConversationItem> ExecuteTool(string ID, FunctionBase function, Dictionary<string, object> parameters, IFunctionExecutor functionExecutor)
    {
        var response = await functionExecutor.Execute(function, parameters);

        return ConversationItem.CreateFunctionCallOutput(ID, response);
    }

    public void ApplyGain(Span<short> audio, int factor)
    {
        for (int i = 0; i < audio.Length; i++)
            audio[i] = unchecked((short)int.Clamp(audio[i] * factor, short.MinValue, short.MaxValue));
    }

    static ConversationTool BuildTool(FunctionBase func)
    {
        BinaryData parms = null;
        var paramBuilder = new StringBuilder();
        var requiredBuilder = new StringBuilder();

        int p = 0;
        foreach (var parm in func.GetParameters())
        {
            var name = JsonEncodedText.Encode(parm.Name);
            var description = JsonEncodedText.Encode(parm.Description);

            if (parm.Type == typeof(string))
                paramBuilder.Append(
$@"""{name}"": {{
    ""type"": ""string"",
    ""description"": ""{description}""
}}");
            else if (parm.Type == typeof(sbyte) ||
                parm.Type == typeof(byte) ||
                parm.Type == typeof(short) ||
                parm.Type == typeof(ushort) ||
                parm.Type == typeof(int) ||
                parm.Type == typeof(uint) ||
                parm.Type == typeof(long) ||
                parm.Type == typeof(ulong) ||
                parm.Type == typeof(float) ||
                parm.Type == typeof(double) ||
                parm.Type == typeof(Int128) ||
                parm.Type == typeof(UInt128))
                paramBuilder.Append(
$@"""{name}"": {{
    ""type"": ""number"",
    ""description"": ""{description}""
}}");
            else if (parm.Type == typeof(bool))
                paramBuilder.Append(
$@"""{name}"": {{
    ""type"": ""boolean"",
    ""description"": ""{description}""
}}");
            else if (parm.Type.IsEnum)
                paramBuilder.Append(
$@"""{name}"": {{
    ""type"": ""string"",
    ""enum"": [ {string.Join(", ", Enum.GetNames(parm.Type).Select(n => $"\"{n}\""))} ],
    ""description"": ""{description}""
}}");
            else
                throw new Exception($"Unsupported type: {parm.Type}.");

            requiredBuilder.Append($"\"{name}\"");

            if (++p < func.ParameterCount)
            {
                paramBuilder.Append(",");
                requiredBuilder.Append(",");
            }
        }

        parms = BinaryData.FromString($@"
            {{
                ""type"": ""object"",
                ""properties"": {{
                    {paramBuilder}
                }},
                ""required"": [ {requiredBuilder} ]
            }}");

        return ConversationTool.CreateFunctionTool(func.Name, func.Description, parms);
    }
}

#pragma warning restore OPENAI002 // Type is for evaluation purposes only and is subject to change or removal in future updates. Suppress this diagnostic to proceed.