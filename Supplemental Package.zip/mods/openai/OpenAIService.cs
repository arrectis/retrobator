﻿using Microsoft.Extensions.Logging;
using Retrobator.Buffers;
using Retrobator.Entities;
using Retrobator.GuiAbstractions;
using Retrobator.Storage;
using System;

namespace Retrobator.AI.OpenAI;

[FriendlyName("OpenAI API")]
sealed class OpenAIService : IEntity, IAppService, IHasAppStorage, IHasWindow
{
    static readonly string[] _conversationModels = ["gpt-4o-realtime-preview", "gpt-4o", "gpt-4o-mini"];
    static readonly string[] _imageModels = ["dall-e-3"];
    const string DefaultApiKey = "(none)";
    const int TypeVersion = 0;
    const int StorageKey = 0;
    Conversation _conversation;
    TextConversation _textConversation;
    ImageGenerator _imageGenerator;
    bool _conversationEnabled;
    string _conversationModel;
    float _conversationTemperature;
    bool _imageGeneratorEnabled;
    string _imageModel;
    string _imageQuality;
    string _imageStyle;
    string _apiKey;
    bool _showApiKey;

    public IContextMap ContextMap { get; set; }
    public ILogger Logger { get; set; }
    public IObjectStore AppStorage { get; set; }
    public IWindowState WindowState { get; set; }
    public string Info => @"Configures access to AI models from OpenAI.";

    public void Initialize()
    {
        string apiKey = DefaultApiKey;

        _conversationEnabled = true;
        _conversationModel = _conversationModels[0];
        _conversationTemperature = 0.8f;
        _imageGeneratorEnabled = true;
        _imageModel = _imageModels[0];
        _imageQuality = ImageGenerator.ImageQualities[0];
        _imageStyle = ImageGenerator.ImageStyles[0];

        try
        {
            var buffer = new Buffer<byte>();
            if (AppStorage.TryGet(StorageKey, buffer.CreateWriter()))
            {
                var reader = buffer.CreateReader();

                _ = reader.ReadInt();
                apiKey = reader.ReadString();
                _conversationEnabled = reader.ReadBool();
                _conversationModel = reader.ReadString();
                _conversationTemperature = reader.ReadFloat();
                _imageGeneratorEnabled = reader.ReadBool();
                _imageModel = reader.ReadString();
                _imageQuality = reader.ReadString();
                _imageStyle = reader.ReadString();
            }
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, $"OpenAI API: Error loading settings.");
        }

        SetApiKey(apiKey);
    }

    public void Shutdown()
    {
        ContextMap.TryRemove<IConversation>(ConversationModelIsLegacy(_conversationModel) ? _textConversation : _conversation);
        ContextMap.TryRemove<IImageGenerator>(_imageGenerator);
        _ = _conversation.DisposeAsync();
    }

    void SetApiKey(string key)
    {
        if (string.IsNullOrEmpty(key))
            key = DefaultApiKey;
        _apiKey = key;

        ContextMap.TryRemove<IConversation>(ConversationModelIsLegacy(_conversationModel) ? _textConversation : _conversation);
        ContextMap.TryRemove<IImageGenerator>(_imageGenerator);

        _conversation = new Conversation(_apiKey, _conversationModel, Logger);
        _conversation.Temperature = _conversationTemperature;
        _textConversation = new TextConversation(_apiKey, _conversationModel);
        _textConversation.Temperature = _conversationTemperature;
        _imageGenerator = new ImageGenerator(_apiKey, _imageModel);
        _imageGenerator.ImageQuality = _imageQuality;
        _imageGenerator.ImageStyle = _imageStyle;

        if (_apiKey == DefaultApiKey)
            return;

        if (_conversationEnabled)
            ContextMap.Add<IConversation>(ConversationModelIsLegacy(_conversationModel) ? _textConversation : _conversation);
        if (_imageGeneratorEnabled)
            ContextMap.Add<IImageGenerator>(_imageGenerator);
    }

    static bool ConversationModelIsLegacy(string model) => model == "gpt-4o" || model == "gpt-4o-mini";

    void SetConversationModel(string model)
    {
        ContextMap.TryRemove<IConversation>(ConversationModelIsLegacy(_conversationModel) ? _textConversation : _conversation);

        _conversationModel = model;

        if (ConversationModelIsLegacy(_conversationModel))
        {
            _textConversation = new TextConversation(_apiKey, _conversationModel);
            _textConversation.Temperature = _conversationTemperature;
            ContextMap.Add<IConversation>(_textConversation);
        }
        else
        {
            _ = _conversation.DisposeAsync();
            _conversation = new Conversation(_apiKey, _conversationModel, Logger);
            _conversation.Temperature = _conversationTemperature;
            ContextMap.Add<IConversation>(_conversation);
        }
    }

    public void DrawWindow(IGui gui)
    {
        bool modified = false;

        gui.Spacing();

        if (gui.Input("API Key:", ref _apiKey, widthRatio: .2f, password: !_showApiKey && _apiKey != DefaultApiKey))
        {
            SetApiKey(_apiKey);
            modified = true;
        }

        gui.CheckBox("Show", ref _showApiKey, sameLine: true, toolTip: "Show the API key in plain text.");

        gui.Spacing();

        gui.Separator("Settings");

        using var disabled = gui.DisabledScope(_apiKey == DefaultApiKey);

        if (gui.CollapsingHeader("Agent", defaultClosed: false))
        {
            using var group = gui.GroupScope(nameof(Conversation));
            using var indent = gui.IndentScope();

            if (gui.CheckBox("Enable", ref _conversationEnabled, toolTip: "Enable the AI conversation agent."))
            {
                if (_conversationEnabled)
                    ContextMap.Add<IConversation>(ConversationModelIsLegacy(_conversationModel) ? _textConversation : _conversation);
                else
                    ContextMap.TryRemove<IConversation>(ConversationModelIsLegacy(_conversationModel) ? _textConversation : _conversation);
                modified = true;
            }

            var selectedIndex = Array.IndexOf(_conversationModels, _conversationModel);
            if (gui.ComboBox("Model:", _conversationModels, ref selectedIndex, widthRatio: .15f, toolTip: _conversationModel))
            {
                SetConversationModel(_conversationModels[selectedIndex]);
                modified = true;
            }

            modified |= gui.Input("Temperature:", _conversation.Temperature, v => _conversation.Temperature = v, widthRatio: .15f, minValue: 0f, maxValue: 2f, slider: true,
                toolTip: "Higher values like 0.8 will make the output more random, while lower values like 0.2 will make it more focused and deterministic.");

            if (gui.Button("Reset to Defaults"))
            {
                _conversationEnabled = true;
                _conversationTemperature = .8f;
                SetConversationModel(_conversationModels[0]);
            }
        }

        if (gui.CollapsingHeader("Image Generator", defaultClosed: false))
        {
            using var group = gui.GroupScope(nameof(ImageGenerator));
            using var indent = gui.IndentScope();

            if (gui.CheckBox("Enable", ref _imageGeneratorEnabled, toolTip: "Enable AI image generation."))
            {
                if (_imageGeneratorEnabled)
                    ContextMap.Add<IImageGenerator>(_imageGenerator);
                else
                    ContextMap.TryRemove<IImageGenerator>(_imageGenerator);
                modified = true;
            }

            var selectedIndex = Array.IndexOf(_imageModels, _imageModel);
            if (gui.ComboBox("Model:", _imageModels, ref selectedIndex, widthRatio: .15f, toolTip: _imageModel))
            {
                ContextMap.TryRemove<IImageGenerator>(_imageGenerator);
                _imageModel = _imageModels[selectedIndex];
                _imageGenerator = new ImageGenerator(_apiKey, _imageModel);
                ContextMap.Add<IImageGenerator>(_imageGenerator);
                modified = true;
            }

            selectedIndex = Array.IndexOf(ImageGenerator.ImageQualities, _imageGenerator.ImageQuality);
            if (gui.ComboBox("Quality:", ImageGenerator.ImageQualities, ref selectedIndex, widthRatio: .15f, toolTip: "Image generation quality. Higher is better, but slower."))
            {
                _imageQuality = _imageGenerator.ImageQuality = ImageGenerator.ImageQualities[selectedIndex];
                modified = true;
            }

            selectedIndex = Array.IndexOf(ImageGenerator.ImageStyles, _imageGenerator.ImageStyle);
            if (gui.ComboBox("Style:", ImageGenerator.ImageStyles, ref selectedIndex, widthRatio: .15f, toolTip: "Image style. 'Vivid' = more hyper-realistic."))
            {
                _imageStyle = _imageGenerator.ImageStyle = ImageGenerator.ImageStyles[selectedIndex];
                modified = true;
            }

            if (gui.Button("Reset to Defaults"))
            {
                ContextMap.TryRemove<IImageGenerator>(_imageGenerator);
                _imageGeneratorEnabled = true;
                _imageModel = _imageModels[0];
                _imageQuality = _imageGenerator.ImageQuality = ImageGenerator.ImageQualities[0];
                _imageStyle = _imageGenerator.ImageStyle = ImageGenerator.ImageStyles[0];
                _imageGenerator = new ImageGenerator(_apiKey, _imageModel);
                ContextMap.Add<IImageGenerator>(_imageGenerator);
            }
        }

        if (modified)
        {
            using var buffer = Buffer<byte>.Rent(nameof(OpenAIService));
            var stream = buffer.CreateWriter();
            stream.Write(TypeVersion);
            stream.Write(_apiKey);
            stream.Write(_conversationEnabled);
            stream.Write(_conversationModel);
            stream.Write(_conversationTemperature);
            stream.Write(_imageGeneratorEnabled);
            stream.Write(_imageModel);
            stream.Write(_imageQuality);
            stream.Write(_imageStyle);
            AppStorage.Set(StorageKey, buffer);
        }
    }
}
