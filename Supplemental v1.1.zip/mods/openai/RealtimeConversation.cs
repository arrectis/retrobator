﻿using Microsoft.Extensions.Logging;
using OpenAI.RealtimeConversation;
using System;
using System.ClientModel;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace Retrobator.AI.OpenAI;

#pragma warning disable OPENAI002 // Type is for evaluation purposes only and is subject to change or removal in future updates. Suppress this diagnostic to proceed.

sealed class RealtimeConversation : IConversation, IAsyncDisposable
{
    public static readonly string[] Voices = ["sage", "echo", "shimmer", "ash", "ballad", "coral", "alloy", "verse"];
    static readonly TimeSpan MaxSessionTime = TimeSpan.FromMinutes(29); // Sessions are currently limited to 30 minutes; recycle before then.
    readonly RealtimeConversationClient _client;
    readonly ILogger _logger;
    readonly SemaphoreSlim _interruptLock = new(1);
    readonly SemaphoreSlim _responseLock = new(1);
    readonly ConcurrentDictionary<string, FunctionBase> _functionsByName = new();
    RealtimeConversationSession _session;
    TimeSpan _sessionBeginTime;
    CancellationTokenSource _sessionCancellationTokenSource;
    string _instructions;
    bool _allowAudioResponse;
    string _responseVoice;
    ICollection<FunctionBase> _functions;
    IFunctionExecutor _functionExecutor;
    ConversationResponse _currentResponse;
    bool _configIsDirty;
    bool _voiceIsDirty;

    public RealtimeConversation(string apiKey, string model, ILogger logger)
    {
        Model = model;
        _logger = logger;

        _client = new RealtimeConversationClient(Model, new ApiKeyCredential(apiKey));
        _configIsDirty = true;
    }

    public async ValueTask DisposeAsync()
    {
        _sessionCancellationTokenSource?.Cancel();
        await _interruptLock.WaitAsync();
        await _responseLock.WaitAsync();
        _session?.Dispose();
    }

    public string Model { get; }
    public float Temperature { get; set; } = 0.8f;

    public ICollection<string> GetValidVoices() => Voices;

    async Task RefreshSessionAsync(CancellationToken cancellationToken)
    {
        var time = TimeSpan.FromTicks(DateTime.UtcNow.Ticks);
        bool sessionExpired = _session != null && time - _sessionBeginTime > MaxSessionTime;

        if (_session == null || sessionExpired || _voiceIsDirty)
        {
            _sessionCancellationTokenSource?.Cancel();

            // Wait for the session thread to finish, if any.
            await _responseLock.WaitAsync();

            try
            {
                _sessionCancellationTokenSource = new CancellationTokenSource();
                _session = await _client.StartConversationSessionAsync(_sessionCancellationTokenSource.Token);
                if (_session == null)
                    throw new Exception("Failed to start conversation session.");

                _configIsDirty = true;

                HandleSession(_session, _sessionCancellationTokenSource.Token);
                _sessionBeginTime = time;
                _logger.LogDebug("Started new conversation session.");
            }
            finally
            {
                _responseLock.Release();
            }
        }

        if (_configIsDirty)
        {
            // Send in the new configuration.
            ConversationSessionOptions options = new()
            {
                //https://platform.openai.com/docs/guides/realtime/integration
                Instructions = _instructions,
                Voice = _responseVoice,
                InputAudioFormat = ConversationAudioFormat.Pcm16,
                OutputAudioFormat = ConversationAudioFormat.Pcm16,
                Temperature = Temperature,
                ContentModalities = ConversationContentModalities.Text,
                TurnDetectionOptions = ConversationTurnDetectionOptions.CreateDisabledTurnDetectionOptions(),

                // Transcribe the input audio so that we can record the text conversation.
                InputTranscriptionOptions = new ConversationInputTranscriptionOptions()
                {
                    Model = "whisper-1",
                },
            };

            if (_allowAudioResponse)
                options.ContentModalities |= ConversationContentModalities.Audio;

            _functionsByName.Clear();
            if (_functions != null)
            {
                foreach (var function in _functions)
                {
                    _functionsByName[function.Name] = function;
                    options.Tools.Add(BuildTool(function));
                }
            }

            await _session.ConfigureSessionAsync(options, cancellationToken);
        }

        _configIsDirty = false;
        _voiceIsDirty = false;
    }

    public Task ConfigureAsync(
        string instructions = null,
        bool? allowAudioResponse = null,
        string responseVoice = null,
        ICollection<FunctionBase> functions = null,
        IFunctionExecutor functionExecutor = null,
        CancellationToken cancellationToken = default)
    {
        if (instructions != null)
            _instructions = instructions;

        if(allowAudioResponse.HasValue)
            _allowAudioResponse = allowAudioResponse.Value;

        if (responseVoice != null)
        {
            _responseVoice = responseVoice;
            _voiceIsDirty = true;
        }

        if (functions != null)
            _functions = functions;

        if (functionExecutor != null)
            _functionExecutor = functionExecutor;

        _configIsDirty = true;

        return Task.CompletedTask;
    }

    public async Task AddSystemTextAsync(
        string text, 
        CancellationToken cancellationToken = default)
    {
        await _interruptLock.WaitAsync();

        try
        {
            await RefreshSessionAsync(cancellationToken);

            await _session.AddItemAsync(ConversationItem.CreateSystemMessage([text]), cancellationToken: cancellationToken);
        }
        finally
        {
            _interruptLock.Release();
        }
    }

    public async Task<ConversationResponse> AddTextAsync(
        string text,
        Action<ConversationResponse> responseCallback = null,
        CancellationToken cancellationToken = default)
    {
        _currentResponse = new ConversationResponse();
        responseCallback?.Invoke(_currentResponse);

        await _interruptLock.WaitAsync();

        try
        {
            if (_responseLock.CurrentCount == 0)
            {
                _logger.LogDebug("Conversation interrupt.");
                await _session.InterruptResponseAsync();
            }

            await RefreshSessionAsync(cancellationToken);

            await _session.AddItemAsync(ConversationItem.CreateUserMessage([text]), cancellationToken: cancellationToken);

            await _responseLock.WaitAsync();

            try
            {
                await _session.StartResponseAsync(_sessionCancellationTokenSource.Token);
            }
            catch (Exception)
            {
                _responseLock.Release();
                throw;
            }
        }
        finally
        {
            _interruptLock.Release();
        }

        return _currentResponse;
    }

    public async Task<ConversationResponse> AddAudioAsync(
        Stream audio,
        Action<ConversationResponse> responseCallback = null,
        CancellationToken cancellationToken = default)
    {
        _currentResponse = new ConversationResponse();
        responseCallback?.Invoke(_currentResponse);

        await _interruptLock.WaitAsync();

        try
        {
            if (_responseLock.CurrentCount == 0)
            {
                _logger.LogDebug("Conversation interrupt.");
                await _session.InterruptResponseAsync();
            }

            await RefreshSessionAsync(cancellationToken);

            await _session.SendInputAudioAsync(audio, cancellationToken);

            await _session.CommitPendingAudioAsync(cancellationToken);

            await _responseLock.WaitAsync();

            try
            {
                await _session.StartResponseAsync(_sessionCancellationTokenSource.Token);
            }
            catch (Exception)
            {
                _responseLock.Release();
                throw;
            }
        }
        finally
        {
            _interruptLock.Release();
        }

        return _currentResponse;
    }

    async void HandleSession(
        RealtimeConversationSession session,
        CancellationToken cancellationToken)
    {
        List<Task<ConversationItem>> toolCallTasks = [];

        try
        {
            await foreach (ConversationUpdate update in session.ReceiveUpdatesAsync(cancellationToken))
            {
                switch (update)
                {
                    case ConversationSessionStartedUpdate sessionStartedUpdate:
                        _logger.LogDebug("Conversation session started.");
                        break;
                    case ConversationSessionConfiguredUpdate conversationSessionConfiguredUpdate:
                        _logger.LogDebug("Conversation session configured.");
                        break;
                    case ConversationInputTranscriptionFailedUpdate inputTranscriptionFailedUpdate:
                        _logger.LogError(inputTranscriptionFailedUpdate.ErrorMessage);
                        break;
                    case ConversationItemStreamingPartDeltaUpdate conversationItemStreamingPartDeltaUpdate:

                        // With audio output enabled, the audio transcript of the delta update contains an approximation of
                        // the words spoken by the model. Without audio output, the text of the delta update will contain
                        // the segments making up the text content of a message.
                        var text = string.IsNullOrEmpty(conversationItemStreamingPartDeltaUpdate.AudioTranscript)
                            ? conversationItemStreamingPartDeltaUpdate.Text
                            : conversationItemStreamingPartDeltaUpdate.AudioTranscript;
                        if (!string.IsNullOrEmpty(text))
                        {
                            _currentResponse.AppendText(text);
                        }

                        if (conversationItemStreamingPartDeltaUpdate.AudioBytes != null)
                        {
                            var bytes = conversationItemStreamingPartDeltaUpdate.AudioBytes.ToArray();
                            _currentResponse.AppendAudio(bytes);
                        }

                        break;
                    case ConversationItemStreamingFinishedUpdate conversationItemStreamingFinishedUpdate:
                        // Item finished updates arrive when all streamed data for an item has arrived and the
                        // accumulated results are available. In the case of function calls, this is the point
                        // where all arguments are expected to be present.
                        if (conversationItemStreamingFinishedUpdate.FunctionName != null)
                        {
                            if (_functionsByName.TryGetValue(conversationItemStreamingFinishedUpdate.FunctionName, out var function) == false)
                            {
                                var errorTask = Task.FromResult(ConversationItem.CreateFunctionCallOutput(conversationItemStreamingFinishedUpdate.FunctionCallId, $"Error: Specified function not available."));
                                toolCallTasks.Add(errorTask);
                                break;
                            }

                            bool errored = false;
                            Dictionary<string, object> args = new();
                            if (conversationItemStreamingFinishedUpdate.FunctionCallArguments != null)
                            {
                                try
                                {
                                    using JsonDocument argumentsJson = JsonDocument.Parse(conversationItemStreamingFinishedUpdate.FunctionCallArguments);

                                    foreach (var prop in argumentsJson.RootElement.EnumerateObject())
                                    {
                                        args[prop.Name] = prop.Value.Clone();
                                    }
                                }
                                catch (JsonException ex)
                                {
                                    errored = true;
                                    _logger.LogError(ex, "OpenAI API returned invalid JSON function call arguments.");
                                }
                            }

                            if (!errored)
                            {
                                // Execute the tool and continue.
                                var task = ExecuteTool(conversationItemStreamingFinishedUpdate.FunctionCallId, function, args, _functionExecutor);
                                toolCallTasks.Add(task);
                            }
                        }

                        break;
                    case ConversationResponseFinishedUpdate conversationResponseFinishedUpdate:
                        _logger.LogDebug("Model response finished.");

                        // TODO: Some day, the API will deliver an actual reason.
                        if (conversationResponseFinishedUpdate.Status != ConversationStatus.Completed)
                        {
                            _logger.LogError($"OpenAI returned '{conversationResponseFinishedUpdate.Status}'. This may mean that your daily limit has been reached for this model, or that you have no more OpenAI credit to use.");

                            if (_responseLock.CurrentCount == 0)
                                _responseLock.Release();

                            break;
                        }

                        // If there are no tools requested by the model, we are done.
                        if (toolCallTasks.Count == 0)
                        {
                            _currentResponse.Complete();
                            _currentResponse = null;

                            if (_responseLock.CurrentCount == 0)
                                _responseLock.Release();

                            break;
                        }

                        // Wait for the tool calls to complete, respond to the model with the results, and wait for the next response.
                        var items = await Task.WhenAll(toolCallTasks);
                        foreach (var item in items)
                        {
                            await session.AddItemAsync(item, cancellationToken: cancellationToken);
                        }
                        toolCallTasks.Clear();

                        // Wait for the next response.
                        await session.StartResponseAsync(cancellationToken);
                        break;
                    case ConversationErrorUpdate conversationErrorUpdate:
                        if (_responseLock.CurrentCount == 0)
                            _responseLock.Release();

                        _logger.LogError(conversationErrorUpdate.Message);
                        break;
                    default:
                        break;
                }
            }
        }
        catch (TaskCanceledException)
        {
            // Session was cancelled or interrupted.
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in conversation session.");
        }
        finally
        {
            if (_responseLock.CurrentCount == 0)
                _responseLock.Release();

            _session?.Dispose();
            _session = null;
        }
    }

    static async Task<ConversationItem> ExecuteTool(string ID, FunctionBase function, Dictionary<string, object> parameters, IFunctionExecutor functionExecutor)
    {
        var response = await functionExecutor.Execute(function, parameters);

        return ConversationItem.CreateFunctionCallOutput(ID, response);
    }

    static ConversationTool BuildTool(FunctionBase func)
    {
        BinaryData parms = null;
        var paramBuilder = new StringBuilder();
        var requiredBuilder = new StringBuilder();

        int p = 0;
        foreach (var parm in func.GetParameters())
        {
            var name = JsonEncodedText.Encode(parm.Name);
            var description = JsonEncodedText.Encode(parm.Description);

            if (parm.Type == typeof(string))
                paramBuilder.Append(
$@"""{name}"": {{
    ""type"": ""string"",
    ""description"": ""{description}""
}}");
            else if (parm.Type == typeof(sbyte) ||
                parm.Type == typeof(byte) ||
                parm.Type == typeof(short) ||
                parm.Type == typeof(ushort) ||
                parm.Type == typeof(int) ||
                parm.Type == typeof(uint) ||
                parm.Type == typeof(long) ||
                parm.Type == typeof(ulong) ||
                parm.Type == typeof(float) ||
                parm.Type == typeof(double) ||
                parm.Type == typeof(Int128) ||
                parm.Type == typeof(UInt128))
                paramBuilder.Append(
$@"""{name}"": {{
    ""type"": ""number"",
    ""description"": ""{description}""
}}");
            else if (parm.Type == typeof(bool))
                paramBuilder.Append(
$@"""{name}"": {{
    ""type"": ""boolean"",
    ""description"": ""{description}""
}}");
            else if (parm.Type.IsEnum)
                paramBuilder.Append(
$@"""{name}"": {{
    ""type"": ""string"",
    ""enum"": [ {string.Join(", ", Enum.GetNames(parm.Type).Select(n => $"\"{n}\""))} ],
    ""description"": ""{description}""
}}");
            else
                throw new Exception($"Unsupported type: {parm.Type}.");

            requiredBuilder.Append($"\"{name}\"");

            if (++p < func.ParameterCount)
            {
                paramBuilder.Append(",");
                requiredBuilder.Append(",");
            }
        }

        parms = BinaryData.FromString($@"
            {{
                ""type"": ""object"",
                ""properties"": {{
                    {paramBuilder}
                }},
                ""required"": [ {requiredBuilder} ]
            }}");

        return ConversationTool.CreateFunctionTool(func.Name, func.Description, parms);
    }
}

#pragma warning restore OPENAI002 // Type is for evaluation purposes only and is subject to change or removal in future updates. Suppress this diagnostic to proceed.