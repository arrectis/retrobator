﻿using OpenAI.Audio;
using OpenAI.Chat;
using System;
using System.Buffers;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace Retrobator.AI.OpenAI;

/// <summary>
/// The sole purpose of this class is to provide an alternative to the <see cref="RealtimeConversation"/> model, which currently has daily limits (and a higher price).
/// </summary>
sealed class LegacyConversation : IConversation
{
    public static readonly string[] Voices = ["nova", "alloy", "echo", "fable", "onyx", "shimmer"];
    const int _maxMessages = 200;
    readonly ChatClient _chatClient;
    readonly AudioClient _transcriptionClient;
    readonly AudioClient _speechClient;
    readonly SemaphoreSlim _exchangeLock = new(1);
    readonly List<ChatMessage> _messages = new();
    bool _allowAudioResponse;
    string _responseVoice;
    ICollection<FunctionBase> _functions;
    IFunctionExecutor _functionExecutor;

    public LegacyConversation(string apiKey, string model)
    {
        Model = model;
        _chatClient = new ChatClient(model, apiKey);
        _transcriptionClient = new AudioClient("whisper-1", apiKey);
        _speechClient = new AudioClient("tts-1", apiKey);

        // Let the first message in the conversation be the instructions.
        _messages.Add(ChatMessage.CreateSystemMessage(""));
    }

    public string Model { get; }
    public float Temperature { get; set; } = 1f;

    public ICollection<string> GetValidVoices() => RealtimeConversation.Voices;

    public Task ConfigureAsync(
        string instructions = null,
        bool? allowAudioResponse = null,
        string responseVoice = null,
        ICollection<FunctionBase> functions = null,
        IFunctionExecutor functionExecutor = null,
        CancellationToken cancellationToken = default)
    {
        if (instructions != null)
            _messages[0] = ChatMessage.CreateSystemMessage(instructions);

        if (allowAudioResponse.HasValue)
            _allowAudioResponse = allowAudioResponse.Value;

        if (responseVoice != null)
            _responseVoice = responseVoice;

        if (functions != null)
            _functions = functions;

        if (functionExecutor != null)
            _functionExecutor = functionExecutor;

        return Task.CompletedTask;
    }

    public async Task AddSystemTextAsync(
        string text,
        CancellationToken cancellationToken = default)
    {
        // Allow only one exchange at a time.
        await _exchangeLock.WaitAsync(cancellationToken);

        try
        {
            // Add the system message.
            _messages.Add(ChatMessage.CreateSystemMessage(text));
            while (_messages.Count > _maxMessages)
                _messages.RemoveAt(1);
        }
        finally
        {
            _exchangeLock.Release();
        }
    }

    public async Task<ConversationResponse> AddTextAsync(
        string text,
        Action<ConversationResponse> responseCallback = null,
        CancellationToken cancellationToken = default)
    {
        // Allow only one exchange at a time.
        await _exchangeLock.WaitAsync(cancellationToken);

        try
        {
            var response = new ConversationResponse();
            responseCallback?.Invoke(response);

            // Add the user message.
            _messages.Add(ChatMessage.CreateUserMessage(text));
            while (_messages.Count > _maxMessages)
                _messages.RemoveAt(1);

            await CreateChatCompletionAsync(response, cancellationToken);

            if (_allowAudioResponse)
            {
                await GenerateSpeechAsync(response.Text, response, cancellationToken);
            }

            response.Complete();

            return response;
        }
        finally
        {
            _exchangeLock.Release();
        }
    }

    public async Task<ConversationResponse> AddAudioAsync(
        Stream audio,
        Action<ConversationResponse> responseCallback = null,
        CancellationToken cancellationToken = default)
    {
        var transcription = await TranscribeAudioAsync(audio, cancellationToken);

        return await AddTextAsync(transcription, responseCallback, cancellationToken);
    }

    async Task<string> TranscribeAudioAsync(Stream audio, CancellationToken cancellationToken)
    {
        var other = new MemoryStream();
        await audio.CopyToAsync(other);
        var buffer = other.ToArray();

        // First, convert PCM to WAV.
        using var memoryStream = new MemoryStream();
        using var writer = new BinaryWriter(memoryStream);
        writer.Write(Encoding.ASCII.GetBytes("RIFF"));
        writer.Write(36 + buffer.Length);
        writer.Write(Encoding.ASCII.GetBytes("WAVE"));
        writer.Write(Encoding.ASCII.GetBytes("fmt "));
        writer.Write(16);
        writer.Write((ushort)1);
        writer.Write((ushort)1);
        writer.Write(24000);
        writer.Write(24000 * 2);
        writer.Write((ushort)2);
        writer.Write((ushort)16);
        writer.Write(Encoding.ASCII.GetBytes("data"));
        writer.Write(buffer.Length);
        if (BitConverter.IsLittleEndian)
        {
            writer.Write(buffer);
        }
        else
        {
            var span = MemoryMarshal.Cast<byte, short>(buffer);
            BinaryPrimitives.ReverseEndianness(span, span);
            writer.Write(buffer);
        }
        writer.Flush();
        memoryStream.Flush();
        memoryStream.Position = 0;

        var options = new AudioTranscriptionOptions
        {
            Language = "en",
            Temperature = 0,
        };

        AudioTranscription transcription = await _transcriptionClient.TranscribeAudioAsync(memoryStream, $"dummy.wav", options, cancellationToken);

        return transcription.Text;
    }

    async Task GenerateSpeechAsync(string text, ConversationResponse conversationResponse, CancellationToken cancellationToken = default)
    {
        string voiceName = _responseVoice ?? Voices[0];

        if (!Voices.Contains(voiceName))
        {
            // Could be a voice from one of the realtime models; try to map it to a similar tts model voice.
            switch (voiceName)
            {
                case "sage":
                    voiceName = "nova";
                    break;
                case "ash":
                    voiceName = "onyx";
                    break;
                case "ballad":
                    voiceName = "onyx";
                    break;
                case "coral":
                    voiceName = "nova";
                    break;
                case "verse":
                    voiceName = "nova";
                    break;
                default:
                    voiceName = Voices[0];
                    break;
            }
        }

        SpeechGenerationOptions options = new()
        {
            ResponseFormat = GeneratedSpeechFormat.Pcm
        };

        var result = await _speechClient.GenerateSpeechAsync(text, new GeneratedSpeechVoice(voiceName), options, cancellationToken);

        var response = result.GetRawResponse();

        const int bufferSize = 16384;
        byte[] buffer = new byte[bufferSize];
        int bytesRead;
        var stream = response.ContentStream;
        while ((bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length)) != 0)
        {
            conversationResponse.AppendAudio(buffer.AsSpan(0, bytesRead));
        }

        await response.ContentStream.DisposeAsync();
    }

    async Task CreateChatCompletionAsync(
        ConversationResponse response,
        CancellationToken cancellationToken)
    {
        var options = new ChatCompletionOptions
        {
            Temperature = Temperature,
        };

        var functionsByName = new Dictionary<string, FunctionBase>();
        if (_functionExecutor != null && _functions != null && _functions.Count > 0)
        {
            options.ToolChoice = ChatToolChoice.CreateAutoChoice();
            options.AllowParallelToolCalls = true;

            foreach (var function in _functions)
            {
                functionsByName[function.Name] = function;
                options.Tools.Add(BuildTool(function));
            }
        }

        List<Task<ToolChatMessage>> toolCallTasks = [];

        for (; ; )
        {
            Dictionary<int, string> indexToToolCallId = [];
            Dictionary<int, string> indexToFunctionName = [];
            Dictionary<int, SequenceBuilder<byte>> indexToFunctionArguments = [];

            var chatUpdates = _chatClient.CompleteChatStreamingAsync(
                _messages,
                options,
                cancellationToken);

            await foreach (var chatUpdate in chatUpdates)
            {
                // Accumulate the text content as new updates arrive.
                foreach (ChatMessageContentPart contentPart in chatUpdate.ContentUpdate)
                {
                    response.AppendText(contentPart.Text);
                }

                // Build the tool calls as new updates arrive.
                foreach (StreamingChatToolCallUpdate toolCallUpdate in chatUpdate.ToolCallUpdates)
                {
                    // Keep track of which tool call ID belongs to this update index.
                    if (toolCallUpdate.ToolCallId != null)
                    {
                        indexToToolCallId[toolCallUpdate.Index] = toolCallUpdate.ToolCallId;
                    }

                    // Keep track of which function name belongs to this update index.
                    if (toolCallUpdate.FunctionName != null)
                    {
                        indexToFunctionName[toolCallUpdate.Index] = toolCallUpdate.FunctionName;
                    }

                    // Keep track of which function arguments belong to this update index,
                    // and accumulate the arguments string as new updates arrive.
                    if (toolCallUpdate.FunctionArgumentsUpdate != null && !toolCallUpdate.FunctionArgumentsUpdate.ToMemory().IsEmpty)
                    {
                        if (!indexToFunctionArguments.TryGetValue(toolCallUpdate.Index, out SequenceBuilder<byte> argumentsBuilder))
                        {
                            argumentsBuilder = new SequenceBuilder<byte>();
                            indexToFunctionArguments[toolCallUpdate.Index] = argumentsBuilder;
                        }

                        argumentsBuilder.Append(toolCallUpdate.FunctionArgumentsUpdate);
                    }
                }

                switch (chatUpdate.FinishReason)
                {
                    case ChatFinishReason.Stop:
                        break;

                    case ChatFinishReason.ToolCalls:
                        {
                            // Create the function tool calls from the accumulated data.
                            List<ChatToolCall> toolCalls = [];

                            foreach ((int index, string toolCallId) in indexToToolCallId)
                            {
                                ReadOnlySequence<byte> sequence = indexToFunctionArguments[index].Build();

                                ChatToolCall toolCall = ChatToolCall.CreateFunctionToolCall(
                                    toolCallId,
                                    indexToFunctionName[index],
                                    BinaryData.FromBytes(BinaryData.FromBytes(sequence.ToArray())));

                                toolCalls.Add(toolCall);
                            }

                            // Add the assistant message with tool calls to the conversation history.
                            _messages.Add(new AssistantChatMessage(toolCalls));

                            foreach (var toolCall in toolCalls)
                            {
                                if (functionsByName.TryGetValue(toolCall.FunctionName, out var function) == false)
                                {
                                    var errorTask = Task.FromResult(ChatMessage.CreateToolMessage(toolCall.Id, $"Error: Specified function not available."));
                                    toolCallTasks.Add(errorTask);
                                    continue;
                                }

                                // Parse the tool call arguments.
                                Dictionary<string, object> args = new();
                                if (toolCall.FunctionArguments != null)
                                {
                                    using JsonDocument argumentsJson = JsonDocument.Parse(toolCall.FunctionArguments);
                                    foreach (var prop in argumentsJson.RootElement.EnumerateObject())
                                    {
                                        args[prop.Name] = prop.Value.Clone();
                                    }
                                }

                                // Execute the tool and continue.
                                var task = ExecuteTool(toolCall.Id, function, args, _functionExecutor);
                                toolCallTasks.Add(task);
                            }

                            break;
                        }

                    case ChatFinishReason.Length:
                        throw new NotImplementedException("Incomplete model output due to MaxTokens parameter or token limit exceeded.");

                    case ChatFinishReason.ContentFilter:
                        throw new NotImplementedException("Omitted content due to a content filter flag.");

                    case ChatFinishReason.FunctionCall:
                        throw new NotImplementedException("Deprecated in favor of tool calls.");

                    case null:
                        break;
                }
            }

            // If there are no tools requested by the model, we are done.
            if (toolCallTasks.Count == 0)
                return;

            // Wait for the tool calls to complete, respond to the model with the results, and wait for the next response.
            var toolMessages = await Task.WhenAll(toolCallTasks);
            _messages.AddRange(toolMessages);
            toolCallTasks.Clear();
        }
    }

    static async Task<ToolChatMessage> ExecuteTool(string ID, FunctionBase function, Dictionary<string, object> parameters, IFunctionExecutor functionExecutor)
    {
        var response = await functionExecutor.Execute(function, parameters);

        return ChatMessage.CreateToolMessage(ID, response);
    }

    static ChatTool BuildTool(FunctionBase func)
    {
        BinaryData parms = null;
        var paramBuilder = new StringBuilder();
        var requiredBuilder = new StringBuilder();

        int p = 0;
        foreach (var parm in func.GetParameters())
        {
            var name = JsonEncodedText.Encode(parm.Name);
            var description = JsonEncodedText.Encode(parm.Description);

            if (parm.Type == typeof(string))
                paramBuilder.Append(
$@"""{name}"": {{
    ""type"": ""string"",
    ""description"": ""{description}""
}}");
            else if (parm.Type == typeof(sbyte) ||
                parm.Type == typeof(byte) ||
                parm.Type == typeof(short) ||
                parm.Type == typeof(ushort) ||
                parm.Type == typeof(int) ||
                parm.Type == typeof(uint) ||
                parm.Type == typeof(long) ||
                parm.Type == typeof(ulong) ||
                parm.Type == typeof(float) ||
                parm.Type == typeof(double) ||
                parm.Type == typeof(Int128) ||
                parm.Type == typeof(UInt128))
                paramBuilder.Append(
$@"""{name}"": {{
    ""type"": ""number"",
    ""description"": ""{description}""
}}");
            else if (parm.Type == typeof(bool))
                paramBuilder.Append(
$@"""{name}"": {{
    ""type"": ""boolean"",
    ""description"": ""{description}""
}}");
            else if (parm.Type.IsEnum)
                paramBuilder.Append(
$@"""{name}"": {{
    ""type"": ""string"",
    ""enum"": [ {string.Join(", ", Enum.GetNames(parm.Type).Select(n => $"\"{n}\""))} ],
    ""description"": ""{description}""
}}");
            else
                throw new Exception($"Unsupported type: {parm.Type}.");

            requiredBuilder.Append($"\"{name}\"");

            if (++p < func.ParameterCount)
            {
                paramBuilder.Append(",");
                requiredBuilder.Append(",");
            }
        }

        parms = BinaryData.FromString($@"
            {{
                ""type"": ""object"",
                ""properties"": {{
                    {paramBuilder}
                }},
                ""required"": [ {requiredBuilder} ]
            }}");

        return ChatTool.CreateFunctionTool(func.Name, func.Description, parms);
    }

    sealed class SequenceBuilder<T>
    {
        Segment _first;
        Segment _last;

        public void Append(ReadOnlyMemory<T> data)
        {
            if (_first == null)
            {
                Debug.Assert(_last == null);
                _first = new Segment(data);
                _last = _first;
            }
            else
            {
                _last = _last!.Append(data);
            }
        }

        public ReadOnlySequence<T> Build()
        {
            if (_first == null)
            {
                Debug.Assert(_last == null);
                return ReadOnlySequence<T>.Empty;
            }

            if (_first == _last)
            {
                Debug.Assert(_first.Next == null);
                return new ReadOnlySequence<T>(_first.Memory);
            }

            return new ReadOnlySequence<T>(_first, 0, _last!, _last!.Memory.Length);
        }

        private sealed class Segment : ReadOnlySequenceSegment<T>
        {
            public Segment(ReadOnlyMemory<T> items) : this(items, 0)
            {
            }

            private Segment(ReadOnlyMemory<T> items, long runningIndex)
            {
                Debug.Assert(runningIndex >= 0);
                Memory = items;
                RunningIndex = runningIndex;
            }

            public Segment Append(ReadOnlyMemory<T> items)
            {
                long runningIndex;
                checked { runningIndex = RunningIndex + Memory.Length; }
                Segment segment = new(items, runningIndex);
                Next = segment;
                return segment;
            }
        }
    }
}
