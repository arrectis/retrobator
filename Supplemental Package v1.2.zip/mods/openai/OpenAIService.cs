﻿using Microsoft.Extensions.Logging;
using Retrobator.Buffers;
using Retrobator.Entities;
using Retrobator.GuiAbstractions;
using Retrobator.Storage;
using System;

namespace Retrobator.AI.OpenAI;

[FriendlyName("OpenAI")]
sealed class OpenAIService : IEntity, IAppService, IHasAppStorage, IHasWindow
{
    static readonly ModelInfo[] _conversationModels =
    [
        new (Name: "gpt-4o-realtime-preview", Description: "The latest and greatest realtime conversation model. \r\nNote: May have daily limits.", IsLegacy: false),
        new (Name: "gpt-4o-mini-realtime-preview", Description: "A cheaper realtime conversation model. \r\nNote: Not great a following instructions. May have daily limits.", IsLegacy: false),
        new (Name: "gpt-4o", Description: "An alternate conversation model. \r\nNote: Best used for text interaction, or as a fallback when daily limits have been reached.", IsLegacy: true),
        new (Name: "gpt-4o-mini", Description: "A cheaper, alternate conversational model. \r\nNote: Best used for text interaction, or as a fallback when daily limits have been reached.", IsLegacy: true)
    ];

    static readonly string[] _imageModels = ["dall-e-3"];
    const string DefaultApiKey = "(none)";
    const int TypeVersion = 0;
    const int StorageKey = 0;
    RealtimeConversation _conversation;
    LegacyConversation _textConversation;
    ImageGenerator _imageGenerator;
    bool _conversationEnabled;
    ModelInfo _conversationModel;
    float _conversationTemperature;
    bool _imageGeneratorEnabled;
    string _imageModel;
    string _imageQuality;
    string _imageStyle;
    string _apiKey;
    bool _showApiKey;

    public IContextMap ContextMap { get; set; }
    public ILogger Logger { get; set; }
    public IObjectStore AppStorage { get; set; }
    public IWindowState WindowState { get; set; }
    public string Info => @"Configures access to OpenAI's AI models.";

    public void Initialize()
    {
        string apiKey = DefaultApiKey;

        _conversationEnabled = true;
        _conversationModel = _conversationModels[0];
        _conversationTemperature = 0.8f;
        _imageGeneratorEnabled = true;
        _imageModel = _imageModels[0];
        _imageQuality = ImageGenerator.ImageQualities[0];
        _imageStyle = ImageGenerator.ImageStyles[0];

        try
        {
            var buffer = new Buffer<byte>();
            if (AppStorage.TryGet(StorageKey, buffer.CreateWriter()))
            {
                var reader = buffer.CreateReader();

                _ = reader.ReadInt();
                apiKey = reader.ReadString();
                _conversationEnabled = reader.ReadBool();
                string conversationModelName = reader.ReadString();
                _conversationTemperature = reader.ReadFloat();
                _imageGeneratorEnabled = reader.ReadBool();
                _imageModel = reader.ReadString();
                _imageQuality = reader.ReadString();
                _imageStyle = reader.ReadString();

                _conversationModel = _conversationModels[0];
                foreach (var model in _conversationModels)
                {
                    if (model.Name == conversationModelName)
                    {
                        _conversationModel = model;
                        break;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Logger.LogError(ex, $"OpenAI API: Error loading settings.");
        }

        SetApiKey(apiKey);
    }

    public void Shutdown()
    {
        ContextMap.TryRemove<IConversation>(_conversationModel.IsLegacy ? _textConversation : _conversation);
        ContextMap.TryRemove<IImageGenerator>(_imageGenerator);
        _ = _conversation.DisposeAsync();
    }

    void SetApiKey(string key)
    {
        if (string.IsNullOrEmpty(key))
            key = DefaultApiKey;
        _apiKey = key;

        ContextMap.TryRemove<IConversation>(_conversationModel.IsLegacy ? _textConversation : _conversation);
        ContextMap.TryRemove<IImageGenerator>(_imageGenerator);

        _conversation = new RealtimeConversation(_apiKey, _conversationModel.Name, Logger);
        _conversation.Temperature = _conversationTemperature;
        _textConversation = new LegacyConversation(_apiKey, _conversationModel.Name);
        _textConversation.Temperature = _conversationTemperature;
        _imageGenerator = new ImageGenerator(_apiKey, _imageModel);
        _imageGenerator.ImageQuality = _imageQuality;
        _imageGenerator.ImageStyle = _imageStyle;

        if (_apiKey == DefaultApiKey)
            return;

        if (_conversationEnabled)
            ContextMap.Add<IConversation>(_conversationModel.IsLegacy ? _textConversation : _conversation);
        if (_imageGeneratorEnabled)
            ContextMap.Add<IImageGenerator>(_imageGenerator);
    }

    void SetConversationModel(ModelInfo model)
    {
        ContextMap.TryRemove<IConversation>(_conversationModel.IsLegacy ? _textConversation : _conversation);

        _conversationModel = model;

        if (_conversationModel.IsLegacy)
        {
            _textConversation = new LegacyConversation(_apiKey, _conversationModel.Name);
            _textConversation.Temperature = _conversationTemperature;
            ContextMap.Add<IConversation>(_textConversation);
        }
        else
        {
            _ = _conversation.DisposeAsync();
            _conversation = new RealtimeConversation(_apiKey, _conversationModel.Name, Logger);
            _conversation.Temperature = _conversationTemperature;
            ContextMap.Add<IConversation>(_conversation);
        }
    }

    public void DrawWindow(IGui gui)
    {
        bool modified = false;

        gui.Spacing();

        if (gui.Input("API Key:", ref _apiKey, widthRatio: .35f, password: !_showApiKey && _apiKey != DefaultApiKey))
        {
            SetApiKey(_apiKey);
            modified = true;
        }

        gui.CheckBox("Show", ref _showApiKey, sameLine: true, toolTip: "Show the API key in plain text.");

        bool disabled = _apiKey == DefaultApiKey;
        if (disabled)
        {
            gui.Text("Status: Disabled. Enter your OpenAI API key to enable.", color: Color.Red);
        }
        else
        {
            gui.Text("Status: Enabled.", color: Color.Green);
            gui.Text("See the 'Assistant' menu for general AI assistant settings.");
        }

        gui.Spacing(4);

        using var disabledScope = gui.DisabledScope(disabled);

        if (gui.CollapsingHeader("Advanced", defaultClosed: true))
        {
            gui.Separator("Agent");

            using (var group = gui.GroupScope(nameof(RealtimeConversation)))
            {
                using var indent = gui.IndentScope();

                if (gui.CheckBox("Enable", ref _conversationEnabled, toolTip: "Enable the AI conversation agent."))
                {
                    if (_conversationEnabled)
                        ContextMap.Add<IConversation>(_conversationModel.IsLegacy ? _textConversation : _conversation);
                    else
                        ContextMap.TryRemove<IConversation>(_conversationModel.IsLegacy ? _textConversation : _conversation);
                    modified = true;
                }

                var selectedIndex = 0;
                for (int i = 0; i < _conversationModels.Length; i++)
                {
                    if (_conversationModels[i] == _conversationModel)
                    {
                        selectedIndex = i;
                        break;
                    }
                }
                if (gui.ComboBox("Model:", _conversationModels, ref selectedIndex, toString: m => m.Name, widthRatio: .25f,
                    toolTip: "Specifies the AI model that you interact with."))
                {
                    SetConversationModel(_conversationModels[selectedIndex]);
                    modified = true;
                }

                using (var indentScope = gui.IndentScope(2))
                {
                    gui.Text(_conversationModels[selectedIndex].Description);
                }

                gui.Spacing(2);

                modified |= gui.Input("Temperature:", _conversation.Temperature, v => _conversation.Temperature = v, widthRatio: .25f, minValue: .6f, maxValue: 1.2f, slider: true,
                    toolTip: "Higher values like 0.8 will make the output more random, while lower values like 0.2 will make it more focused and deterministic.");

                if (gui.Button("Reset to Defaults"))
                {
                    _conversationEnabled = true;
                    _conversationTemperature = .8f;
                    SetConversationModel(_conversationModels[0]);
                }
            }

            gui.Separator("Image Generation");

            using (var group = gui.GroupScope(nameof(ImageGenerator)))
            {
                using var indent = gui.IndentScope();

                if (gui.CheckBox("Enable", ref _imageGeneratorEnabled, toolTip: "Enable AI image generation."))
                {
                    if (_imageGeneratorEnabled)
                        ContextMap.Add<IImageGenerator>(_imageGenerator);
                    else
                        ContextMap.TryRemove<IImageGenerator>(_imageGenerator);
                    modified = true;
                }

                var selectedIndex = Array.IndexOf(_imageModels, _imageModel);
                if (gui.ComboBox("Model:", _imageModels, ref selectedIndex, widthRatio: .25f,
                    toolTip: "Specifies the model that should be used for image generation tasks."))
                {
                    ContextMap.TryRemove<IImageGenerator>(_imageGenerator);
                    _imageModel = _imageModels[selectedIndex];
                    _imageGenerator = new ImageGenerator(_apiKey, _imageModel);
                    ContextMap.Add<IImageGenerator>(_imageGenerator);
                    modified = true;
                }

                selectedIndex = Array.IndexOf(ImageGenerator.ImageQualities, _imageGenerator.ImageQuality);
                if (gui.ComboBox("Quality:", ImageGenerator.ImageQualities, ref selectedIndex, widthRatio: .25f, toolTip: "Image generation quality. Higher is better, but slower."))
                {
                    _imageQuality = _imageGenerator.ImageQuality = ImageGenerator.ImageQualities[selectedIndex];
                    modified = true;
                }

                selectedIndex = Array.IndexOf(ImageGenerator.ImageStyles, _imageGenerator.ImageStyle);
                if (gui.ComboBox("Style:", ImageGenerator.ImageStyles, ref selectedIndex, widthRatio: .25f, toolTip: "Image style. 'Vivid' = more hyper-realistic."))
                {
                    _imageStyle = _imageGenerator.ImageStyle = ImageGenerator.ImageStyles[selectedIndex];
                    modified = true;
                }

                if (gui.Button("Reset to Defaults"))
                {
                    ContextMap.TryRemove<IImageGenerator>(_imageGenerator);
                    _imageGeneratorEnabled = true;
                    _imageModel = _imageModels[0];
                    _imageQuality = _imageGenerator.ImageQuality = ImageGenerator.ImageQualities[0];
                    _imageStyle = _imageGenerator.ImageStyle = ImageGenerator.ImageStyles[0];
                    _imageGenerator = new ImageGenerator(_apiKey, _imageModel);
                    ContextMap.Add<IImageGenerator>(_imageGenerator);
                }
            }
        }

        if (modified)
        {
            using var buffer = Buffer<byte>.Rent(nameof(OpenAIService));
            var stream = buffer.CreateWriter();
            stream.Write(TypeVersion);
            stream.Write(_apiKey);
            stream.Write(_conversationEnabled);
            stream.Write(_conversationModel.Name);
            stream.Write(_conversationTemperature);
            stream.Write(_imageGeneratorEnabled);
            stream.Write(_imageModel);
            stream.Write(_imageQuality);
            stream.Write(_imageStyle);
            AppStorage.Set(StorageKey, buffer);
        }
    }

    readonly record struct ModelInfo(string Name, string Description, bool IsLegacy);
}
